const titulo = document.getElementById("titulo")
titulo.innerHTML = "Barber Tip 2022"